# Third-Party Components and Attribution

The following files are third-party dependencies and are **not original project source code**.

## ROSLIB.js

- File: `web/roslib.min.js`
- Project: Robot Web Tools — roslibjs
- Website: https://robotwebtools.github.io/roslibjs/
- Repository: https://github.com/RobotWebTools/roslibjs
- License: BSD-family license (check the exact version bundled in the project against its upstream release/license file before redistribution).

## nipplejs

- File: `web/nipplejs.min.js`
- Project: nipplejs
- Repository: https://github.com/yoannmoinet/nipplejs
- Version indicated by the bundled file header: 0.10.1
- License: MIT

## Course Reference

The web-control implementation was developed with course guidance from:

- Steven Eu Kok Seng — RoboticSensorROS
- https://stevenviewr.github.io/RoboticSensorROS/

## Unitree Go2 Simulation Reference

The coursework used an existing Unitree Go2 ROS 2 simulation as a base:

- https://github.com/anujjain-dev/unitree-go2-ros2

When sharing this portfolio repository, keep these attributions and avoid representing third-party or course-provided code as independently authored from scratch.
