# Code Explanation for Technical Review

This document explains the important parts of the uploaded web-control code in simple technical terms.

## 1. `index.html` — Camera Viewer

### Purpose
Displays the simulated Unitree Go2 camera stream in a browser.

### Key idea
The page reads the ROS/computer IP address from the browser URL:

```javascript
const urlParams = new URLSearchParams(window.location.search);
const ros_ip = urlParams.get('ros_ip') || 'localhost';
```

This makes the page reusable on different computers. If no IP is supplied, it falls back to `localhost`.

It then constructs the camera-stream URL:

```javascript
const videoUrl = `http://${ros_ip}:8080/video`;
```

and assigns it to the `<img>` element. The actual video frames are produced by the separate camera-streaming backend used by the wider project.

**How to explain it:**
> “The browser does not directly subscribe to the ROS image message in this page. It displays an HTTP video stream from the backend running on port 8080.”

---

## 2. `button_control.html` — Button Teleoperation

### Purpose
Controls forward, backward and stop movement from browser buttons while also showing the camera feed.

### ROS connection

```javascript
const rosbridgeUrl = `ws://${ros_ip}:9090`;
const ros = new ROSLIB.Ros({ url: rosbridgeUrl });
```

This connects the web page to `rosbridge_server` using WebSocket.

### Publisher

```javascript
var cmdVel = new ROSLIB.Topic({
  ros: ros,
  name: '/cmd_vel',
  messageType: 'geometry_msgs/Twist'
});
```

This creates a browser-side publisher for robot velocity commands.

### Movement commands

A positive `linear.x` value moves forward, a negative value moves backward, and all-zero values stop the robot.

**How to explain it:**
> “Each button creates a Twist message and publishes it to `/cmd_vel`. I change `linear.x` for forward or backward movement, while the stop button publishes zeros.”

---

## 3. `teleop.html` — Keyboard Teleoperation

### Purpose
Uses W/A/S/D and Space to control the robot from the keyboard.

### Input mapping

- `W` -> forward
- `S` -> backward
- `A` -> rotate left
- `D` -> rotate right
- `Space` -> stop

### Continuous publishing

This version stores the current velocity in `vx` and `wz`, then publishes every 50 ms:

```javascript
timer = setInterval(() => {
  cmdVel.publish(new ROSLIB.Message({
    linear:  {x: vx, y: 0, z: 0},
    angular: {x: 0, y: 0, z: wz}
  }));
}, 50);
```

50 ms corresponds to about **20 commands per second (20 Hz)**.

This is useful because many mobile-base/robot controllers expect velocity commands to continue arriving rather than receiving only one message.

When the key is released, the interval is stopped and a final zero-velocity command is published.

**How to explain it:**
> “I used keydown to start a repeated command loop and keyup to stop it. This keeps the velocity command active while I hold the key and immediately sends zero velocity when I release it.”

---

## 4. `joystick.html` — Virtual Joystick

### Purpose
Provides proportional browser-based control using the `nipplejs` joystick library.

### ROS topic

The uploaded version publishes to:

```text
/cmd_vel_smoothed
```

instead of `/cmd_vel`.

### Converting joystick movement into robot velocity

The code reads:

- joystick angle -> direction
- joystick distance -> command strength

Then it calculates:

```javascript
linear.x  = Math.sin(angle) * max_linear * force
angular.z = -Math.cos(angle) * max_angular * force
```

This allows proportional control: a small joystick movement produces a smaller command, while moving farther from the centre produces a larger command.

When the joystick is released, it publishes zero linear and angular velocity.

**How to explain it:**
> “Instead of fixed button speeds, the joystick gives proportional control. I convert the joystick angle into forward/turn direction and the joystick distance into speed, then publish the result as a Twist message.”

### Technical note
If `/cmd_vel_smoothed` is used, the ROS 2 system must have a node/controller configured to consume that topic or relay/smooth it into the robot’s actual command input.

---

## 5. `relay.html` — Relay Topic Test

### Purpose
Demonstrates sending a simple non-motion command from the browser into ROS 2.

The page creates a publisher for:

```text
/relay_int
```

using:

```text
std_msgs/Int32
```

The ON button publishes `1`; the OFF button publishes `0`.

**How to explain it:**
> “This page demonstrates that the same browser-to-ROS architecture can control more than movement. A web button publishes an integer ROS message that could be consumed by a relay-control node.”

---

## 6. `roslib.min.js`

This is a third-party library from Robot Web Tools. It provides the JavaScript API used to connect the browser to rosbridge and to create ROS topic/message objects.

**Do not describe this file as code written for the project.**

---

## 7. `nipplejs.min.js`

This is a third-party virtual joystick library. The project uses it to capture joystick movement in the browser.

**Do not describe this file as code written for the project.**

---

# End-to-End Explanation

A concise explanation for an interviewer:

> “The browser gets the robot computer’s IP from the URL. ROSLIB.js then opens a WebSocket connection to rosbridge on port 9090. Depending on the page, user input comes from buttons, keyboard keys or a virtual joystick. That input is converted into a `geometry_msgs/Twist` message and published to a ROS 2 velocity topic. The robot controller consumes the command and moves the Unitree Go2 in simulation. Separately, the simulated camera is published by ROS 2 and converted by the backend into a web stream that the browser displays.”

# What I Would Be Ready to Explain in a Follow-up

- Why ROS 2 uses topics and message types
- What `/cmd_vel` is
- Difference between `linear.x` and `angular.z`
- Why rosbridge is needed for browser-to-ROS communication
- Why a WebSocket is used
- Why the keyboard version publishes continuously
- How the virtual joystick converts angle/distance to motion
- Difference between the camera ROS topic and the HTTP video stream
- Why third-party libraries and course/open-source sources are credited
