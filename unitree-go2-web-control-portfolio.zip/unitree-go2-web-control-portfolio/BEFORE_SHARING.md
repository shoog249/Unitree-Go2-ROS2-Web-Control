# Before Sharing With the Interviewer

- [ ] Add the modified `gazebo.xacro` if you still have the exact file used in the project.
- [ ] Add `serving_webpage_simulation_camera.py` if you still have your actual tested copy.
- [ ] Add one screenshot or short GIF/video link showing the simulation and browser control working.
- [ ] Confirm `/cmd_vel_smoothed` is intentional and explain what node/controller consumes it.
- [ ] Do not add ROS-generated `build/`, `install/`, or `log/` folders.
- [ ] Do not add passwords, tokens, private keys, or sensitive network details.
- [ ] Keep the course and third-party attribution in the repository.
- [ ] If university/course rules restrict publishing the material, share a private review copy or only the files you are permitted to distribute.
